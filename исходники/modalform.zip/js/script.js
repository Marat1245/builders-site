function reachGoal(goal) {
    //console.log('try: ' + goal);
    if (typeof yaCounter29566650 !== "undefined") {
        yaCounter29566650.reachGoal(goal);
        //console.log('send: ' + goal);
    }
}
